package com.softtek.persistence;

import java.io.Serializable;

import org.springframework.data.annotation.Id;

public class Alumno implements Serializable {

	@Id
	private String ID; // El id debe ser de tipo String

	private Integer numAlumno;
	private String nombre;
	private double nota;

	public Alumno() {
		// TODO Auto-generated constructor stub
	}

	public Alumno(Integer numAlumno, String nombre, double nota) {
		super();
		this.numAlumno = numAlumno;
		this.nombre = nombre;
		this.nota = nota;
	}
	
	public String getID() {
		return ID;
	}
	
	public void setID(String iD) {
		ID = iD;
	}

	public Integer getNumAlumno() {
		return numAlumno;
	}

	public void setNumAlumno(Integer numAlumno) {
		this.numAlumno = numAlumno;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public double getNota() {
		return nota;
	}

	public void setNota(double nota) {
		this.nota = nota;
	}

	@Override
	public String toString() {
		return "Alumno [ID=" + ID + ", numAlumno=" + numAlumno + ", nombre=" + nombre + ", nota=" + nota + "]";
	}

}
