package com.softtek.persistence;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

@RepositoryRestResource(collectionResourceRel = "ALUMNOS", path = "alumnos")
public interface AlumnosDAO extends MongoRepository<Alumno, String>{
	
	// Mostrar todos los alumnos
	// http://localhost:8080/alumnos
	
	// Buscar un alumno por su PK
	// http://localhost:8080/alumnos/1
	
	// Utilizamos los metodos heredados de CrudRepository
	// https://docs.spring.io/spring-data/jpa/docs/current/reference/html/
	
	// Podemos crear nuestros propios metodos utilizando palabras clave
	// https://docs.spring.io/spring-data/jpa/docs/current/reference/html/#repository-query-keywords
	
	// Buscar un alumno por su nombre
	// http://localhost:8080/alumnos/search/findByNombre?nombre=Maria
	public List<Alumno> findByNombre(String nombre);
	
	// Mostrar todos los alumnos ordenados por nota
	// http://localhost:8080/alumnos/search/OrderByNota
	public List<Alumno> OrderByNota();
	
	// Mostrar todos los alumnos ordenados por nota descendente
	// http://localhost:8080/alumnos/search/OrderByNotaDesc
	public List<Alumno> OrderByNotaDesc();
	
	// Abrir import.sql y poner 3 alumnos con la misma nota
	// Buscar por nota y ordenados por nombre descendente
	// http://localhost:8080/alumnos/search/findByNotaOrderByNombreDesc?nota=7.2
	public List<Alumno> findByNotaOrderByNombreDesc(double nota);
	
	// Buscar los alumnos con nota entre 5 y 10 
	// http://localhost:8080/alumnos/search/findByNotaBetween?min=5&max=10
	public List<Alumno> findByNotaBetween(double min, double max);
	
	
	// Todos los metodos implementados se pueden ver en esta url
	// http://localhost:8080/alumnos/search

}
