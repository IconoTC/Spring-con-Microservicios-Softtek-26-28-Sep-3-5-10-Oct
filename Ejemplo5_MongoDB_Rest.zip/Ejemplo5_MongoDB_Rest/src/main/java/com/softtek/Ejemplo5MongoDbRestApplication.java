package com.softtek;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.softtek.persistence.Alumno;
import com.softtek.persistence.AlumnosDAO;

@SpringBootApplication
public class Ejemplo5MongoDbRestApplication implements CommandLineRunner{

	@Autowired
	private AlumnosDAO dao;

	@Override
	public void run(String... args) throws Exception {
		// borrar todos los documentos (alumnos)
		//dao.deleteAll();
		
		// Alta de 6 alumnos
//		dao.save(new Alumno(1, "Juan", 7.2));
//		dao.save(new Alumno(2, "Maria", 8.6));
//		dao.save(new Alumno(3, "Pedro", 3.5));
//		dao.save(new Alumno(4, "Sara", 7.2));
//		dao.save(new Alumno(5, "Gonzalo", 4.7));
//		dao.save(new Alumno(6, "Laura", 7.2));
		
		// Mostrar todos los alumnos
		System.out.println("----- Todos los alumnos -----");
		dao.findAll().forEach(System.out::println);
		
		// Buscar alumno por ID
		System.out.println("Buscar por ID: " + dao.findById("6515a10ea4463b5b2e9f7506").get());
		
		// Buscar un alumno por nombre
		System.out.println("Buscar por nombre: " + dao.findByNombre("Maria"));
		
		// Mostrar todos los alumnos ordenados por nota ascendente
		System.out.println("----- Todos los alumnos por nota ascendente -----");
		dao.OrderByNota().forEach(System.out::println);
		
		// Mostrar todos los alumnos ordenados por nota descendente
		System.out.println("----- Todos los alumnos por nota descendente -----");
		dao.OrderByNotaDesc().forEach(System.out::println);
		
		// Buscar por nota ordenados por nombre descendente
		System.out.println("----- Alumnos por nota ordenados por nombre descendente -----");
		dao.findByNotaOrderByNombreDesc(7.2).forEach(System.out::println);
		
		// Buscar los alumnos con nota entre 5 y 10
		System.out.println("----- Alumnos aprobados ----");
		dao.findByNotaBetween(5, 10).forEach(System.out::println);
		
	}
	
	public static void main(String[] args) {
		SpringApplication.run(Ejemplo5MongoDbRestApplication.class, args);
	}

}
