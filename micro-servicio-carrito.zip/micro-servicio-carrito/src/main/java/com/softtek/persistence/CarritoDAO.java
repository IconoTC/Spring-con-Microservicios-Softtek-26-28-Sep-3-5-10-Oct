package com.softtek.persistence;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import com.softtek.models.Carrito;

@RepositoryRestResource(collectionResourceRel = "carritos", path = "carritos")
public interface CarritoDAO extends MongoRepository<Carrito, String>{
	
	// URL para poder acceder
	// http://localhost:8003/carritos
	
	// http://localhost:8003/carritos/search/findByUsuario?usuario=Maria
	public Carrito findByUsuario(String usuario);

}
