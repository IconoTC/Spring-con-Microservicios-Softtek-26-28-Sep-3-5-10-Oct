package com.softtek.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.softtek.clients.ItemClientRest;
import com.softtek.models.Carrito;
import com.softtek.models.Item;
import com.softtek.persistence.CarritoDAO;

@Service
public class CarritoServiceImpl implements CarritoService{
	
	@Autowired
	private CarritoDAO dao;
	
	@Autowired
	private ItemClientRest clienteFeign;

	@Override
	public Carrito crear(String usuario) {
		Carrito carrito = new Carrito();
		carrito.setUsuario(usuario);
		
		return dao.save(carrito);
	}

	@Override
	public void agregarItem(Long id, Integer cantidad, String usuario) {
		Item item = clienteFeign.crearItem(id, cantidad);
		Carrito carrito = dao.findByUsuario(usuario);
		carrito.getContenido().add(item);
		carrito.setImporte(carrito.getImporte() + 
				(item.getProducto().getPrecio() * cantidad));
		dao.save(carrito);
	}

	@Override
	public Carrito buscar(String usuario) {
		return dao.findByUsuario(usuario);
	}

	@Override
	public void eliminarItem(Long id, String usuario) {
		Carrito carrito = dao.findByUsuario(usuario);
		List<Item> contenido = carrito.getContenido();
		
		Item encontrado = null;
		for (Item item : contenido) {
			if (id == item.getProducto().getID()) {
				encontrado = item;
				break;
			}
		}
		
		contenido.remove(encontrado);
		carrito.setImporte(carrito.getImporte() - 
				(encontrado.getProducto().getPrecio() * encontrado.getCantidad()));
		
		dao.save(carrito);
	}

}








