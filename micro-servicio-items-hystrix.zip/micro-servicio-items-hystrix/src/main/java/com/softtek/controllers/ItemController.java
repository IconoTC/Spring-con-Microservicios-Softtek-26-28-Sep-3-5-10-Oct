package com.softtek.controllers;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.softtek.models.Item;
import com.softtek.models.Producto;
import com.softtek.services.ItemService;

@RestController
public class ItemController {
	
	// La anotacion @Autowired no permite poner el id del bean a inyectar
	// La solucion es @Qualifier	
	//@Autowired
	//@Qualifier("serviceRestTemplate")
	 
	// @Resource si que me permite poner el id del bean
	//@Resource(name = "serviceFeign")
	@Resource(name ="serviceRestTemplate")
	private ItemService itemService;
	
	// http://localhost:8002/ver/2/cantidad/100
	@GetMapping("/ver/{id}/cantidad/{cantidad}")
	
	// En el caso de recibir una excepcion llamar al metodo manejarError
	@HystrixCommand(fallbackMethod = "manejarError")
	public Item crearItem(@PathVariable Long id, @PathVariable Integer cantidad) {
		return itemService.buscarItem(id, cantidad);
	}
	
	
	public Item manejarError(Long id, Integer cantidad, Throwable ex) {
		// com.netflix.hystrix.exception.HystrixTimeoutException
		
		System.out.println(ex.getMessage() + "********************");
		System.out.println(ex.getClass() + "----------------------");
		
		Producto producto = new Producto();
		producto.setID(id);
		producto.setDescripcion("Producto vacio");
		producto.setPrecio(0);
		
		return new Item(producto, cantidad);
	}

}
