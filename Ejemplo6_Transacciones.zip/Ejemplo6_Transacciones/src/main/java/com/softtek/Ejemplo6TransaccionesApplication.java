package com.softtek;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.softtek.persistence.Alumno;
import com.softtek.persistence.AlumnosDAO;

@SpringBootApplication
public class Ejemplo6TransaccionesApplication implements CommandLineRunner{
	
	@Autowired
	private AlumnosDAO dao;
	
	@Override
	public void run(String... args) throws Exception {
		// Crear una lista con 3 alumnos y persistir
		List<Alumno> lista = new ArrayList<Alumno>();
		lista.add(new Alumno(1, "Juan", 7.2));
		lista.add(new Alumno(2, "Maria", 3.5));
		lista.add(new Alumno(3, "Pedro", 6.3));
		
		// Crear un alumno con error para que haga el rollback
		// No genera error, si la PK ya existe, en JPA se entiende como UPDATE
		lista.add(new Alumno(2, "Susana", 5.7));
		
		// Un alumno vacio, que no tiene PK, genera una excepcion
		lista.add(new Alumno());
		
		try {
			insertar(lista);
		} catch(Exception ex) {
			System.out.println("Ha ocurrido un error");
		}
		
		// Mostrar todos los alumnos
		System.out.println("---- Todos los alumnos -----");
		dao.findAll().forEach(System.out::println);
		System.out.println("Cuantos alumnos tengo? " + dao.count());
		
	}
	
	@Transactional(propagation = Propagation.REQUIRED,
			isolation = Isolation.SERIALIZABLE,
			rollbackFor = Exception.class)
	public void insertar(List<Alumno> lista) {
		
		// El metodo save gestiona cada transaccion de forma independiente
		// dao.save(alumno);
		
		// El metodo saveAll se gestiona como una transaccion unica
		dao.saveAll(lista);
	}

	public static void main(String[] args) {
		SpringApplication.run(Ejemplo6TransaccionesApplication.class, args);
	}

}
