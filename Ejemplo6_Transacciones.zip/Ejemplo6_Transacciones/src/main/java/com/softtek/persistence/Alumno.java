package com.softtek.persistence;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "ALUMNOS")
public class Alumno implements Serializable {

	@Id
	@Column(name = "NUM_ALUMNO")
	private Integer numAlumno;

	@Column(name = "NOMBRE", length = 50)
	private String nombre;

	@Column(name = "NOTA")
	private double nota;

	public Alumno() {
		// TODO Auto-generated constructor stub
	}

	public Alumno(Integer numAlumno, String nombre, double nota) {
		super();
		this.numAlumno = numAlumno;
		this.nombre = nombre;
		this.nota = nota;
	}

	public Integer getNumAlumno() {
		return numAlumno;
	}

	public void setNumAlumno(Integer numAlumno) {
		this.numAlumno = numAlumno;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public double getNota() {
		return nota;
	}

	public void setNota(double nota) {
		this.nota = nota;
	}

	@Override
	public String toString() {
		return "Alumno [numAlumno=" + numAlumno + ", nombre=" + nombre + ", nota=" + nota + "]";
	}

}
