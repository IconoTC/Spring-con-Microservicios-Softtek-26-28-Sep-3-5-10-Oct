package com.softtek.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

@FeignClient(url = "localhost:8080", name="servicio")
public interface ClienteGradosRest {
	
	@RequestMapping("/fahrenheit/{grados}")
	public double gradosAFahrenheit(@PathVariable  double grados);
	
	@RequestMapping("/grados/{fahrenheit}")
	public double fahrenheitAGrados(@PathVariable  double fahrenheit);

}
