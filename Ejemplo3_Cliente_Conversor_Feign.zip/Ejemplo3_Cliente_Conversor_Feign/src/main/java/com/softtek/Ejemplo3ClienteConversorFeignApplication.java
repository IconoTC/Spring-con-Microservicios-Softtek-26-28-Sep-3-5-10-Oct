package com.softtek;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.Bean;

import com.softtek.client.ClienteGradosRest;

@SpringBootApplication
@EnableFeignClients
public class Ejemplo3ClienteConversorFeignApplication {
	
	@Autowired
	private ClienteGradosRest clienteFeign;
	
	@Bean
	public CommandLineRunner run() {
		return datos -> {
			System.out.println("37 grados centigrados son " +
		        clienteFeign.gradosAFahrenheit(37) + " grados fahrenheit");
			
			System.out.println("98.6 grados fahrenheit son " + 
				clienteFeign.fahrenheitAGrados(98.6) + " grados centigrados");
		};
	}
	

	public static void main(String[] args) {
		SpringApplication.run(Ejemplo3ClienteConversorFeignApplication.class, args);
	}

}
