package com.softtek.services;

import com.softtek.models.Item;

public interface ItemService {
	
	Item buscarItem(Long id, Integer cantidad);

}
