package com.softtek;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;

@SpringBootApplication
public class Ejemplo2ClienteConversorRestTemplateApplication {
	
	@Bean
	public RestTemplate restTemplate(RestTemplateBuilder builder) {
		return builder.build();
	}
	
	@Bean
	public CommandLineRunner run(RestTemplate restTemplate) {
		return datos -> {
			double fahrenheit = restTemplate.getForObject(
					"http://localhost:8080/fahrenheit/37", Double.class);
			System.out.println("37 grados centigrados son " + fahrenheit + " grados fahrenheit");
			
			double grados =  restTemplate.getForObject(
					"http://localhost:8080/grados/98.6", Double.class);
			System.out.println("98.6 grados fahrenheit son " + grados + " grados centigrados");
		};
	}

	
	public static void main(String[] args) {
		SpringApplication.run(Ejemplo2ClienteConversorRestTemplateApplication.class, args);
	}

}
