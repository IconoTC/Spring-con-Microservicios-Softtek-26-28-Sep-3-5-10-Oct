package com.softtek.persistence;

import org.springframework.data.repository.CrudRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import com.softtek.models.Persona;

@RepositoryRestResource(collectionResourceRel = "PERSONAS", path = "personas")
public interface PersonasDAO extends CrudRepository<Persona, Long>{
	
	// Mostrar todas las personas
	// http://localhost:8080/personas

}
