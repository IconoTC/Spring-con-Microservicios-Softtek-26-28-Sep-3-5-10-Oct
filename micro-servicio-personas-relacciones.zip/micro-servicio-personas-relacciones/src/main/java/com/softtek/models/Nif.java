package com.softtek.models;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "nifs")
public class Nif implements Serializable {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "nif_id")
	private Long id;
	
	private long numero;
	private char letra;
	
	@OneToOne(mappedBy = "nif")  // Es la propiedad nif en la entidad Persona, debe ser igual
	private Persona persona;
	
	public Nif() {
		// TODO Auto-generated constructor stub
	}

	public Nif(long numero, char letra) {
		super();
		this.numero = numero;
		this.letra = letra;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public long getNumero() {
		return numero;
	}

	public void setNumero(long numero) {
		this.numero = numero;
	}

	public char getLetra() {
		return letra;
	}

	public void setLetra(char letra) {
		this.letra = letra;
	}

	public Persona getPersona() {
		return persona;
	}

	public void setPersona(Persona persona) {
		this.persona = persona;
	}

	@Override
	public String toString() {
		return "Nif [id=" + id + ", numero=" + numero + ", letra=" + letra + "]";
	}
	
}
