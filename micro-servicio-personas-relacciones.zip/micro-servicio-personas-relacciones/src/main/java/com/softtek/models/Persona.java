package com.softtek.models;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "personas")
public class Persona implements Serializable{
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "persona_id")   // PK xxxx_id
	private Long id;
	
	private String nombre;
	
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "id_nif", referencedColumnName = "nif_id")     // FK id_xxxxx
	private Nif nif;
	
	@OneToMany(mappedBy = "persona", cascade = CascadeType.ALL)
	private Set<Telefono> telefonos = new HashSet<>();
	
	@ManyToMany(cascade = {CascadeType.MERGE, CascadeType.DETACH, CascadeType.PERSIST, CascadeType.REFRESH})
	@JoinTable(name = "personas_coches",
			   joinColumns = @JoinColumn(name="persona_id", referencedColumnName = "persona_id"),
			   inverseJoinColumns = @JoinColumn(name="coche_id", referencedColumnName = "coche_id"))
	private Set<Coche> coches = new HashSet<Coche>();
	
	public Persona() {
		// TODO Auto-generated constructor stub
	}

	public Persona(String nombre, Nif nif) {
		super();
		this.nombre = nombre;
		this.nif = nif;
	}
	
	// Metodos de sincronizacion. Se utiliza uno por cada propiedad de tipo coleccion
	public void addTelefono(Telefono telefono) {
		telefonos.add(telefono);
		telefono.setPersona(this);
	}
	
	public void addCoche(Coche coche) {
		coches.add(coche);
		coche.getPropietarios().add(this);
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public Nif getNif() {
		return nif;
	}

	public void setNif(Nif nif) {
		this.nif = nif;
	}

	public Set<Telefono> getTelefonos() {
		return telefonos;
	}

	public void setTelefonos(Set<Telefono> telefonos) {
		this.telefonos = telefonos;
	}

	public Set<Coche> getCoches() {
		return coches;
	}

	public void setCoches(Set<Coche> coches) {
		this.coches = coches;
	}

	@Override
	public String toString() {
		return "Persona [id=" + id + ", nombre=" + nombre + ", nif=" + nif + ", telefonos=" + telefonos + ", coches="
				+ coches + "]";
	}
	
	
	

}
