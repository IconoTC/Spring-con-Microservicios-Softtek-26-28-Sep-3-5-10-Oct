package com.softtek;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.softtek.models.Coche;
import com.softtek.models.Nif;
import com.softtek.models.Persona;
import com.softtek.models.Telefono;
import com.softtek.persistence.PersonasDAO;

@SpringBootApplication
public class MicroServicioPersonasRelaccionesApplication implements CommandLineRunner{
	
	@Autowired
	private PersonasDAO dao;
	
	@Override
	public void run(String... args) throws Exception {
		
		// Crear 3 nifs
		Nif nif1 = new Nif(11_111_111L, 'A'); 
		Nif nif2 = new Nif(22_222_222L, 'B'); 
		Nif nif3 = new Nif(33_333_333L, 'C'); 
		
		// Crear 6 telefonos
		Telefono t1 = new Telefono(616111111);
		Telefono t2 = new Telefono(616222222);
		Telefono t3 = new Telefono(616333333);
		Telefono t4 = new Telefono(616444444);
		Telefono t5 = new Telefono(616555555);
		Telefono t6 = new Telefono(616666666);
		
		// Crear 4 coches
		Coche c1 = new Coche("1111-LMG", "A3");
		Coche c2 = new Coche("2222-LMG", "A4");
		Coche c3 = new Coche("3333-LMG", "A5");
		Coche c4 = new Coche("4444-LMG", "A6");
		
		// Crear 3 personas
		Persona p1 = new Persona("Juan", nif1);
		Persona p2 = new Persona("Pedro", nif2);
		Persona p3 = new Persona("Maria", nif3);
		
		// Asignar 2 telefonos a cada persona
		p1.addTelefono(t1);
		p1.addTelefono(t2);
		
		p2.addTelefono(t3);
		p2.addTelefono(t4);
		
		p3.addTelefono(t5);
		p3.addTelefono(t6);
		
		// Asignar los coches
		p1.addCoche(c1);
		p1.addCoche(c2);
		p1.addCoche(c3);
		
		p2.addCoche(c2);
		p2.addCoche(c3);
		p2.addCoche(c4);
		
		p3.addCoche(c1);
		p3.addCoche(c4);
		
		// Persistir las personas
		dao.save(p1);
		dao.save(p2);
		dao.save(p3);
		
	}

	public static void main(String[] args) {
		SpringApplication.run(MicroServicioPersonasRelaccionesApplication.class, args);
	}

	

}
