package com.softtek.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.softtek.clients.ProductoClienteRest;
import com.softtek.models.Item;


@Service("serviceFeign")
public class ItemServiceFeign implements ItemService{
	
	@Autowired
	private ProductoClienteRest clienteFeign;

	@Override
	public Item buscarItem(Long id, Integer cantidad) {
		return new Item(clienteFeign.buscar(id), cantidad) ;
	}

}
