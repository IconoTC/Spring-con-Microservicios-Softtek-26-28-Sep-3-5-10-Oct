package com.softtek;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.softtek.persistence.Alumno;
import com.softtek.persistence.AlumnosDAO;

@SpringBootApplication
public class Ejemplo4JpaRestApplication  implements CommandLineRunner{

	@Autowired
	private AlumnosDAO dao;
	
	
	@Override
	public void run(String... args) throws Exception {
		
		System.out.println("Cuantos registros tenemos? " + dao.count());
		
		dao.save(new Alumno("Manuel", 10));
		
		System.out.println("----- Todos los alumnos -----");
		dao.findAll().forEach(System.out::println); 
		
		// buscar por PK
		System.out.println("Buscar un alumno");
		System.out.println(dao.findById(7).get());
		
		// borrar si existe
		dao.findById(7).ifPresent(encontrado -> dao.delete(encontrado));
		
		System.out.println("----- Todos los alumnos -----");
		dao.findAll().forEach(System.out::println);
		
		System.out.println("----- Buscar a Maria -----");
		dao.findByNombre("Maria").forEach(System.out::println);
		

		
	}

	
	
	public static void main(String[] args) {
		SpringApplication.run(Ejemplo4JpaRestApplication.class, args);
	}

	
}
