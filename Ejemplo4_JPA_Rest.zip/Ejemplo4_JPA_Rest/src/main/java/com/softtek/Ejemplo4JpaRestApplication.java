package com.softtek;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ejemplo4JpaRestApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ejemplo4JpaRestApplication.class, args);
	}

}
