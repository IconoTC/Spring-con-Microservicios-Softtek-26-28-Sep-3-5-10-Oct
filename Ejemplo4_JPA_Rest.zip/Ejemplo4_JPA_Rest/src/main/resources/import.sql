insert into ALUMNOS (NOMBRE, NOTA) values ('Juan', 7.2);
insert into ALUMNOS (NOMBRE, NOTA) values ('Maria', 8.6);
insert into ALUMNOS (NOMBRE, NOTA) values ('Pedro', 3.5);
insert into ALUMNOS (NOMBRE, NOTA) values ('Sara', 9.5);
insert into ALUMNOS (NOMBRE, NOTA) values ('Gonzalo', 4.7);
insert into ALUMNOS (NOMBRE, NOTA) values ('Laura', 7);