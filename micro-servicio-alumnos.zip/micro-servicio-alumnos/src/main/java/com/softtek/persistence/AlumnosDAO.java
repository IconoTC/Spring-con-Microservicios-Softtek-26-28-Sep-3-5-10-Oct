package com.softtek.persistence;

import org.springframework.data.repository.CrudRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import com.softtek.models.Alumno;

@RepositoryRestResource(collectionResourceRel = "ALUMNOS", path = "alumnos")
public interface AlumnosDAO extends CrudRepository<Alumno, Integer>{
	
	// Mostrar todos los alumnos
	// http://localhost:8080/alumnos

}
