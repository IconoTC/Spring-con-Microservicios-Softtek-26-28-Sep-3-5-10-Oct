package com.softtek;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.softtek.models.Alumno;
import com.softtek.persistence.AlumnosDAO;

@SpringBootApplication
public class MicroServicioAlumnosApplication implements CommandLineRunner{
	
	@Autowired
	private AlumnosDAO dao;

	public static void main(String[] args) {
		SpringApplication.run(MicroServicioAlumnosApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		
		dao.save(new Alumno("Maria", 8.9));
		
	}

}
