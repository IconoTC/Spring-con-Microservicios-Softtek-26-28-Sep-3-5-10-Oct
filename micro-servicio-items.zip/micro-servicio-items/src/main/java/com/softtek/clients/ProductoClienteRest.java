package com.softtek.clients;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.softtek.models.Producto;

@FeignClient(url = "localhost:8001", name = "servicio-productos")
public interface ProductoClienteRest {
	
	@GetMapping("/buscar/{id}")
	public Producto buscar(@PathVariable Long id);

}
