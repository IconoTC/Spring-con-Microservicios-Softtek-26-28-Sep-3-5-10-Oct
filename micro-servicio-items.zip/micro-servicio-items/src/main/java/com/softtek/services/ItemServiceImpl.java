package com.softtek.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.softtek.models.Item;
import com.softtek.models.Producto;

@Service("serviceRestTemplate")
public class ItemServiceImpl implements ItemService{
	
	@Autowired
	private RestTemplate restTemplate;

	@Override
	public Item buscarItem(Long id, Integer cantidad) {
		Producto producto = restTemplate.getForObject(
				"http://localhost:8001/buscar/{id}", Producto.class, id);
		return new Item(producto, cantidad) ;
	}

}
